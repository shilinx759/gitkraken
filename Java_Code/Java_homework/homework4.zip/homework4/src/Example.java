public class Example {
    public static void main(String[] args) {
        Window win=new Window();
        win.setBounds(100,100,310,260);
        win.setTitle("计算器");
    }
}
